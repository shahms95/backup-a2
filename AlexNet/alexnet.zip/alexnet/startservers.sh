#!/bin/bash

source cluster_utils.sh
start_cluster startserver.py single
